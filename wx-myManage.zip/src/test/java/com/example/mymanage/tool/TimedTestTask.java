package com.example.mymanage.tool;

import org.junit.Test;


public class TimedTestTask {

    @Test
    public void personChanged() {
//        TimedTask.checkDBModify();
    }
}