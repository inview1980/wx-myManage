package com.example.mymanage.pojo;

import lombok.Data;

@Data
public class DebugState {
    private boolean debug=false;

}
