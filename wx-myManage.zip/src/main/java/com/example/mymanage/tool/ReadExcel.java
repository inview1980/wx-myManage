package com.example.mymanage.tool;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.fastjson.JSONArray;
import com.example.mymanage.db.DBChangeSignEnum;
import com.example.mymanage.http.HttpResultEnum;
import com.example.mymanage.iface.IGetAllList;
import com.example.mymanage.iface.IRentRecordDB;
import com.example.mymanage.iface.IRoomDB;
import com.example.mymanage.iface.IWriteToDB;
import com.example.mymanage.pojo.*;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Slf4j
public class ReadExcel {
    @Value("${resource.default-db-file}")
    private String path;
    @Autowired
    private ApplicationContext context;


    /**
     * 根据DBChangeSignEnum枚举中的值，读取相应的数据并保存到excel文件中
     *
     * @return
     */
    public byte[] saveDB2File() {
        val excel = new ExcelExportUtil();
        try {
            for (DBChangeSignEnum value : DBChangeSignEnum.values()) {
                List<?> allList = ((IGetAllList<?>) context.getBean(value.getBeanClass())).getAllList();
                log.info("读取表{}数据，共{}项。", value.getPojoClass().getSimpleName(), allList.size());
                if (value == DBChangeSignEnum.MyUser) {//如果是MyUser表，加密密码后再保存
                    List<MyUser> tmpLst = new ArrayList<>();
                    for (Object user : allList) {
                        MyUser u = (MyUser) ((MyUser) user).clone();
                        u.setPassword(EncryptUtil.encode(u.getPassword(), u.getKey()));
                        tmpLst.add(u);
                    }
                    excel.add(tmpLst);
                    continue;
                }
                excel.add(allList);
            }
        } catch (CloneNotSupportedException e) {
            log.error(e.getLocalizedMessage());
            throw new MyException(HttpResultEnum.UploadFileError);
        }
        return excel.build().write();
    }
    /**
     * 根据DBChangeSignEnum枚举中的值，读取相应的数据并保存到excel文件中
     */
    public InputStream saveDB2FileByEasyExcel() throws CloneNotSupportedException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();

        ExcelWriter excelWriter = EasyExcel.write(os).build();
        for (DBChangeSignEnum value : DBChangeSignEnum.values()) {
            List<?> allList = ((IGetAllList<?>) context.getBean(value.getBeanClass())).getAllList();
            if(value==DBChangeSignEnum.MyUser){//如果是MyUser表，加密密码后再保存
                List<MyUser> tmpLst=new ArrayList<>();
                for (Object user : allList) {
                    MyUser u= (MyUser) ((MyUser)user).clone();
                    u.setPassword(EncryptUtil.encode(u.getPassword(),u.getKey()));
                    tmpLst.add(u);
                }
                String simpleName = value.getPojoClass().getSimpleName();
                excelWriter.write(tmpLst, EasyExcel.writerSheet(simpleName).head(value.getPojoClass()).build());
                continue;
            }
            String simpleName = value.getPojoClass().getSimpleName();
            excelWriter.write(allList, EasyExcel.writerSheet(simpleName).head(value.getPojoClass()).build());
        }
        excelWriter.finish();
        return new ByteArrayInputStream(os.toByteArray());
    }

    public void readXlsToDB(@NonNull String path) {
        readXlsToDB(null, path);
    }

    private void readXlsToDB(InputStream inputStream, String path) {
        for (DBChangeSignEnum value : DBChangeSignEnum.values()) {
            List<?> allList = ((IGetAllList<?>) context.getBean(value.getBeanClass())).getAllList();
            allList.clear();
            if (null != inputStream) {
                EasyExcel.read(inputStream, value.getPojoClass(), new MyExcelListener(allList)).excelType(ExcelTypeEnum.XLSX)
                        .sheet(value.getPojoClass().getSimpleName()).doReadSync();
            } else {
                EasyExcel.read(path, value.getPojoClass(), new MyExcelListener(allList))
                        .sheet(value.getPojoClass().getSimpleName()).doReadSync();
            }
            ((IWriteToDB) context.getBean(value.getBeanClass())).writeToDB();
        }
    }

    public void readXlsToDB(@NonNull InputStream inputStream) {
        readXlsToDB(inputStream, null);
    }

    public void readXls() {
        for (DBChangeSignEnum value : DBChangeSignEnum.values()) {
            List<?> allList = ((IGetAllList<?>) context.getBean(value.getBeanClass())).getAllList();
            allList.clear();
            EasyExcel.read(path, value.getPojoClass(), new MyExcelListener(allList)).sheet(value.getPojoClass().getSimpleName()).doReadSync();
        }
    }

//    public InputStream zipFiles() {
//        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
//            try (ZipOutputStream zipOutputStream = new ZipOutputStream(os)) {
//                for (DBChangeSignEnum value : DBChangeSignEnum.values()) {
//                    List<?> allList = ((IGetAllList<?>) context.getBean(value.getBeanClass())).getAllList();
//                    ZipEntry zipEntry = new ZipEntry(value.getBeanClass().getSimpleName());
//                    zipOutputStream.putNextEntry(zipEntry);
//                    String tmpStr = JSONArray.toJSONString(allList);
//                    zipOutputStream.write(tmpStr.getBytes());
//                }
//                zipOutputStream.closeEntry();
//            }
//            return new ByteArrayInputStream(os.toByteArray());
//        } catch (IOException e) {
//            log.error(e.getLocalizedMessage());
//            throw new MyException(HttpResultEnum.UploadFileError);
//        }
//    }

    public static class MyExcelListener<T> extends AnalysisEventListener<T> {
        private List<T> tmpLst;

        public MyExcelListener(List<T> tmpLst) {
            this.tmpLst = tmpLst;
        }


        public void invoke(T data, AnalysisContext context) {
            tmpLst.add(data);
        }


        public void doAfterAllAnalysed(AnalysisContext context) {

        }
    }
}
