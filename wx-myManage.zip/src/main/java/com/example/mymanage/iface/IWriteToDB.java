package com.example.mymanage.iface;

import org.apache.poi.ss.formula.functions.T;

import java.util.List;

public interface IWriteToDB {
    boolean writeToDB();
    void removeDB();
}
