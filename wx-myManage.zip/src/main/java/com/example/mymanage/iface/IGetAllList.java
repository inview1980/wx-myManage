package com.example.mymanage.iface;

import org.apache.poi.ss.formula.functions.T;

import java.util.List;

public interface IGetAllList<T> {
    List<T> getAllList();
}
